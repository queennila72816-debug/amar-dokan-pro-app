-- ============================================================================
-- AMAR DOKAN PRO - ATOMIC OPERATIONS MIGRATION
-- RPCs for Purchase, Stock Transfer, Account Transfer, Stock Adjustment, and Due Payments
-- ============================================================================

-- 1. Atomic Purchase Transaction RPC
CREATE OR REPLACE FUNCTION complete_purchase_transaction(
    p_purchase JSONB,
    p_items JSONB
)
RETURNS JSONB AS $$
DECLARE
    v_purchase_id UUID;
    v_business_id UUID;
    v_branch_id UUID;
    v_supplier_id UUID;
    v_invoice_num VARCHAR(100);
    v_item RECORD;
    v_prev_stock NUMERIC;
    v_new_stock NUMERIC;
    v_prod_name VARCHAR(255);
    v_paid NUMERIC;
    v_due NUMERIC;
    v_total NUMERIC;
    v_payment_method VARCHAR(50);
    v_target_account_id UUID;
BEGIN
    v_business_id := (p_purchase->>'business_id')::UUID;
    v_branch_id := NULLIF(p_purchase->>'branch_id', '')::UUID;
    v_supplier_id := NULLIF(p_purchase->>'supplier_id', '')::UUID;
    v_invoice_num := p_purchase->>'invoice_number';
    v_total := COALESCE((p_purchase->>'total')::NUMERIC, 0);
    v_paid := COALESCE((p_purchase->>'paid')::NUMERIC, 0);
    v_due := COALESCE((p_purchase->>'due')::NUMERIC, 0);
    v_payment_method := COALESCE(p_purchase->>'payment_method', 'cash');

    -- Security check: Ensure caller belongs to the business
    IF auth.uid() IS NOT NULL AND NOT user_belongs_to_business(v_business_id) THEN
        RAISE EXCEPTION 'Unauthorized: User does not belong to this business';
    END IF;

    -- 1. Insert Master Purchase Record
    INSERT INTO purchases (
        business_id, branch_id, supplier_id, supplier_name,
        invoice_number, subtotal, transport_cost, other_cost,
        total, paid, due, payment_method, status, notes
    ) VALUES (
        v_business_id,
        v_branch_id,
        v_supplier_id,
        p_purchase->>'supplier_name',
        v_invoice_num,
        COALESCE((p_purchase->>'subtotal')::NUMERIC, 0),
        COALESCE((p_purchase->>'transport_cost')::NUMERIC, 0),
        COALESCE((p_purchase->>'other_cost')::NUMERIC, 0),
        v_total,
        v_paid,
        v_due,
        v_payment_method,
        CASE WHEN v_due <= 0 THEN 'paid' ELSE 'due' END,
        p_purchase->>'notes'
    ) RETURNING id INTO v_purchase_id;

    -- 2. Insert Purchase Items & Increment Stock atomically
    FOR v_item IN SELECT * FROM jsonb_to_recordset(p_items) AS x(
        product_id UUID, product_name VARCHAR, quantity NUMERIC,
        purchase_price NUMERIC, sale_price NUMERIC, total NUMERIC
    )
    LOOP
        INSERT INTO purchase_items (
            purchase_id, product_id, product_name, quantity,
            purchase_price, sale_price, total
        ) VALUES (
            v_purchase_id, v_item.product_id, v_item.product_name, v_item.quantity,
            v_item.purchase_price, COALESCE(v_item.sale_price, 0), v_item.total
        );

        -- Lock and get product stock
        SELECT current_stock, name INTO v_prev_stock, v_prod_name 
        FROM products WHERE id = v_item.product_id FOR UPDATE;

        IF NOT FOUND THEN
            RAISE EXCEPTION 'Product with ID % not found', v_item.product_id;
        END IF;

        v_new_stock := v_prev_stock + v_item.quantity;

        -- Update Product stock and purchase price
        UPDATE products 
        SET current_stock = v_new_stock, 
            purchase_price = v_item.purchase_price,
            updated_at = CURRENT_TIMESTAMP 
        WHERE id = v_item.product_id;

        -- Record Stock Movement
        INSERT INTO stock_movements (
            business_id, branch_id, product_id, product_name,
            movement_type, quantity, previous_stock, new_stock, reference, note
        ) VALUES (
            v_business_id, v_branch_id, v_item.product_id, v_prod_name,
            'purchase_in', v_item.quantity, v_prev_stock, v_new_stock, 
            v_invoice_num, 'ক্রয় চালান: ' || v_invoice_num
        );
    END LOOP;

    -- 3. Supplier Balance & Transaction update
    IF v_supplier_id IS NOT NULL THEN
        UPDATE suppliers
        SET current_due = current_due + v_due,
            total_purchase = total_purchase + v_total,
            total_paid = total_paid + v_paid,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = v_supplier_id;

        INSERT INTO supplier_transactions (
            business_id, supplier_id, supplier_name, transaction_type,
            amount, balance_after, payment_method, reference_id, note
        )
        SELECT v_business_id, id, name, 'purchase_bill', v_total, current_due, v_payment_method, v_invoice_num, 'ক্রয় চালান: ' || v_invoice_num
        FROM suppliers WHERE id = v_supplier_id;
    END IF;

    -- 4. Deduct payment from cash/bank account if paid > 0
    IF v_paid > 0 THEN
        IF p_purchase ? 'account_id' AND NULLIF(p_purchase->>'account_id', '') IS NOT NULL THEN
            v_target_account_id := (p_purchase->>'account_id')::UUID;
        ELSE
            SELECT id INTO v_target_account_id FROM accounts 
            WHERE business_id = v_business_id AND account_type = 'cash' 
            LIMIT 1;
        END IF;

        IF v_target_account_id IS NOT NULL THEN
            UPDATE accounts
            SET balance = balance - v_paid, updated_at = CURRENT_TIMESTAMP
            WHERE id = v_target_account_id;

            INSERT INTO account_transactions (
                business_id, account_id, transaction_type, amount, balance_after, reference_id, note
            )
            SELECT v_business_id, v_target_account_id, 'purchase_payment', -v_paid, balance, v_invoice_num, 'ক্রয় বিল পরিশোধ: ' || v_invoice_num
            FROM accounts WHERE id = v_target_account_id;
        END IF;
    END IF;

    -- 5. Audit Log
    INSERT INTO audit_logs (
        business_id, branch_id, action, entity_type, entity_id, details
    ) VALUES (
        v_business_id, v_branch_id, 'PURCHASE_CREATED', 'purchase', v_purchase_id::TEXT,
        'ক্রয় রেকর্ড: ' || v_invoice_num || ', মোট: ৳' || v_total
    );

    RETURN jsonb_build_object(
        'success', true, 
        'purchase_id', v_purchase_id, 
        'invoice_number', v_invoice_num
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;


-- 2. Atomic Account-to-Account Transfer RPC
CREATE OR REPLACE FUNCTION transfer_account_funds(
    p_business_id UUID,
    p_from_account_id UUID,
    p_to_account_id UUID,
    p_amount NUMERIC,
    p_note TEXT DEFAULT NULL
)
RETURNS JSONB AS $$
DECLARE
    v_from_bal NUMERIC;
    v_to_bal NUMERIC;
    v_from_name VARCHAR(150);
    v_to_name VARCHAR(150);
    v_ref_id VARCHAR(100);
BEGIN
    IF p_amount <= 0 THEN
        RAISE EXCEPTION 'Transfer amount must be greater than zero';
    END IF;

    IF p_from_account_id = p_to_account_id THEN
        RAISE EXCEPTION 'Source and destination accounts cannot be the same';
    END IF;

    IF auth.uid() IS NOT NULL AND NOT user_belongs_to_business(p_business_id) THEN
        RAISE EXCEPTION 'Unauthorized: User does not belong to this business';
    END IF;

    -- Lock and check source account
    SELECT balance, name INTO v_from_bal, v_from_name 
    FROM accounts WHERE id = p_from_account_id AND business_id = p_business_id 
    FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Source account not found in this business';
    END IF;

    IF v_from_bal < p_amount THEN
        RAISE EXCEPTION 'Insufficient balance in source account % (Balance: %, Transfer: %)', v_from_name, v_from_bal, p_amount;
    END IF;

    -- Lock destination account
    SELECT balance, name INTO v_to_bal, v_to_name 
    FROM accounts WHERE id = p_to_account_id AND business_id = p_business_id 
    FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Destination account not found in this business';
    END IF;

    v_ref_id := 'TRF-' || to_char(CURRENT_TIMESTAMP, 'YYYYMMDD-HH24MISS');

    -- Deduct from source
    UPDATE accounts 
    SET balance = balance - p_amount, updated_at = CURRENT_TIMESTAMP 
    WHERE id = p_from_account_id;

    -- Credit to destination
    UPDATE accounts 
    SET balance = balance + p_amount, updated_at = CURRENT_TIMESTAMP 
    WHERE id = p_to_account_id;

    -- Source transaction record
    INSERT INTO account_transactions (
        business_id, account_id, transaction_type, amount, balance_after, reference_id, note
    ) VALUES (
        p_business_id, p_from_account_id, 'transfer_out', -p_amount, v_from_bal - p_amount, v_ref_id, 
        COALESCE(p_note, 'Transfer to ' || v_to_name)
    );

    -- Destination transaction record
    INSERT INTO account_transactions (
        business_id, account_id, transaction_type, amount, balance_after, reference_id, note
    ) VALUES (
        p_business_id, p_to_account_id, 'transfer_in', p_amount, v_to_bal + p_amount, v_ref_id, 
        COALESCE(p_note, 'Transfer from ' || v_from_name)
    );

    -- Audit log
    INSERT INTO audit_logs (
        business_id, action, entity_type, entity_id, details
    ) VALUES (
        p_business_id, 'ACCOUNT_TRANSFER', 'account', v_ref_id,
        'Transferred ' || p_amount || ' from ' || v_from_name || ' to ' || v_to_name
    );

    RETURN jsonb_build_object(
        'success', true,
        'reference_id', v_ref_id,
        'from_balance', v_from_bal - p_amount,
        'to_balance', v_to_bal + p_amount
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;


-- 3. Atomic Stock Transfer between Branches RPC
CREATE OR REPLACE FUNCTION transfer_branch_stock(
    p_business_id UUID,
    p_product_id UUID,
    p_quantity NUMERIC,
    p_from_branch_id UUID,
    p_to_branch_id UUID,
    p_user_role VARCHAR(50) DEFAULT 'admin',
    p_note TEXT DEFAULT NULL
)
RETURNS JSONB AS $$
DECLARE
    v_prod_name VARCHAR(255);
    v_overall_stock NUMERIC;
    v_from_branch_name VARCHAR(150);
    v_to_branch_name VARCHAR(150);
    v_from_stock NUMERIC := 0;
    v_to_stock NUMERIC := 0;
    v_transfer_ref VARCHAR(100);
BEGIN
    IF p_quantity <= 0 THEN
        RAISE EXCEPTION 'Transfer quantity must be greater than zero';
    END IF;

    IF p_from_branch_id = p_to_branch_id THEN
        RAISE EXCEPTION 'Source and destination branches cannot be the same';
    END IF;

    IF auth.uid() IS NOT NULL AND NOT user_belongs_to_business(p_business_id) THEN
        RAISE EXCEPTION 'Unauthorized: User does not belong to this business';
    END IF;

    -- Validate and lock product
    SELECT name, current_stock INTO v_prod_name, v_overall_stock 
    FROM products WHERE id = p_product_id AND business_id = p_business_id 
    FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Product not found in this business';
    END IF;

    -- Branch names
    SELECT name INTO v_from_branch_name FROM branches WHERE id = p_from_branch_id AND business_id = p_business_id;
    SELECT name INTO v_to_branch_name FROM branches WHERE id = p_to_branch_id AND business_id = p_business_id;

    IF v_from_branch_name IS NULL OR v_to_branch_name IS NULL THEN
        RAISE EXCEPTION 'One or both branches not found in this business';
    END IF;

    v_transfer_ref := 'TF-' || to_char(CURRENT_TIMESTAMP, 'YYYYMMDD-HH24MISS');

    -- Branch-level stock update
    -- Source branch stock
    SELECT stock_quantity INTO v_from_stock 
    FROM product_branch_stock 
    WHERE business_id = p_business_id AND branch_id = p_from_branch_id AND product_id = p_product_id
    FOR UPDATE;

    IF v_from_stock IS NULL THEN
        -- If no branch stock record yet, initialize it
        v_from_stock := v_overall_stock;
        INSERT INTO product_branch_stock (business_id, branch_id, product_id, stock_quantity)
        VALUES (p_business_id, p_from_branch_id, p_product_id, v_from_stock);
    END IF;

    IF v_from_stock < p_quantity THEN
        RAISE EXCEPTION 'Insufficient stock in source branch % (Available: %, Transfer: %)', v_from_branch_name, v_from_stock, p_quantity;
    END IF;

    -- Deduct from source branch
    UPDATE product_branch_stock 
    SET stock_quantity = stock_quantity - p_quantity, updated_at = CURRENT_TIMESTAMP
    WHERE business_id = p_business_id AND branch_id = p_from_branch_id AND product_id = p_product_id;

    -- Add to destination branch
    INSERT INTO product_branch_stock (business_id, branch_id, product_id, stock_quantity)
    VALUES (p_business_id, p_to_branch_id, p_product_id, p_quantity)
    ON CONFLICT (branch_id, product_id)
    DO UPDATE SET stock_quantity = product_branch_stock.stock_quantity + p_quantity, updated_at = CURRENT_TIMESTAMP;

    -- Record outgoing stock movement
    INSERT INTO stock_movements (
        business_id, branch_id, product_id, product_name,
        movement_type, quantity, previous_stock, new_stock, reference, note
    ) VALUES (
        p_business_id, p_from_branch_id, p_product_id, v_prod_name,
        'transfer_out', -p_quantity, v_from_stock, v_from_stock - p_quantity,
        v_transfer_ref, 'Transfer to ' || v_to_branch_name || COALESCE(': ' || p_note, '')
    );

    -- Record incoming stock movement
    INSERT INTO stock_movements (
        business_id, branch_id, product_id, product_name,
        movement_type, quantity, previous_stock, new_stock, reference, note
    ) VALUES (
        p_business_id, p_to_branch_id, p_product_id, v_prod_name,
        'transfer_in', p_quantity, 0, p_quantity,
        v_transfer_ref, 'Transfer from ' || v_from_branch_name || COALESCE(': ' || p_note, '')
    );

    -- Audit log
    INSERT INTO audit_logs (
        business_id, action, entity_type, entity_id, details
    ) VALUES (
        p_business_id, 'STOCK_TRANSFER', 'stock', p_product_id::TEXT,
        'Transferred ' || p_quantity || ' of ' || v_prod_name || ' from ' || v_from_branch_name || ' to ' || v_to_branch_name
    );

    RETURN jsonb_build_object(
        'success', true,
        'reference', v_transfer_ref,
        'product_id', p_product_id,
        'quantity', p_quantity,
        'from_branch', v_from_branch_name,
        'to_branch', v_to_branch_name
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;


-- 4. Atomic Stock Adjustment RPC
CREATE OR REPLACE FUNCTION adjust_product_stock(
    p_business_id UUID,
    p_branch_id UUID,
    p_product_id UUID,
    p_adjusted_qty NUMERIC,
    p_reason VARCHAR(100),
    p_note TEXT DEFAULT NULL
)
RETURNS JSONB AS $$
DECLARE
    v_prev_stock NUMERIC;
    v_new_stock NUMERIC;
    v_prod_name VARCHAR(255);
    v_ref VARCHAR(100);
BEGIN
    IF auth.uid() IS NOT NULL AND NOT user_belongs_to_business(p_business_id) THEN
        RAISE EXCEPTION 'Unauthorized: User does not belong to this business';
    END IF;

    SELECT name, current_stock INTO v_prod_name, v_prev_stock 
    FROM products WHERE id = p_product_id AND business_id = p_business_id 
    FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Product not found in this business';
    END IF;

    v_new_stock := GREATEST(0, v_prev_stock + p_adjusted_qty);
    v_ref := 'ADJ-' || to_char(CURRENT_TIMESTAMP, 'YYYYMMDD-HH24MISS');

    -- Update Product stock
    UPDATE products 
    SET current_stock = v_new_stock, updated_at = CURRENT_TIMESTAMP 
    WHERE id = p_product_id;

    -- Record stock movement
    INSERT INTO stock_movements (
        business_id, branch_id, product_id, product_name,
        movement_type, quantity, previous_stock, new_stock, reference, note
    ) VALUES (
        p_business_id, p_branch_id, p_product_id, v_prod_name,
        'adjustment', p_adjusted_qty, v_prev_stock, v_new_stock,
        v_ref, 'Adjustment: ' || p_reason || COALESCE(' (' || p_note || ')', '')
    );

    -- Audit log
    INSERT INTO audit_logs (
        business_id, branch_id, action, entity_type, entity_id, details
    ) VALUES (
        p_business_id, p_branch_id, 'STOCK_ADJUSTMENT', 'stock', p_product_id::TEXT,
        'Stock adjusted for ' || v_prod_name || ': ' || v_prev_stock || ' -> ' || v_new_stock || ' (' || p_reason || ')'
    );

    RETURN jsonb_build_object(
        'success', true,
        'product_id', p_product_id,
        'previous_stock', v_prev_stock,
        'new_stock', v_new_stock,
        'reference', v_ref
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;


-- 5. Atomic Customer Due Collection RPC
CREATE OR REPLACE FUNCTION collect_customer_due_payment(
    p_business_id UUID,
    p_customer_id UUID,
    p_amount NUMERIC,
    p_payment_method VARCHAR(50),
    p_account_id UUID,
    p_note TEXT DEFAULT NULL
)
RETURNS JSONB AS $$
DECLARE
    v_cust_name VARCHAR(150);
    v_prev_due NUMERIC;
    v_new_due NUMERIC;
    v_acc_bal NUMERIC;
    v_ref VARCHAR(100);
BEGIN
    IF p_amount <= 0 THEN
        RAISE EXCEPTION 'Collection amount must be greater than zero';
    END IF;

    IF auth.uid() IS NOT NULL AND NOT user_belongs_to_business(p_business_id) THEN
        RAISE EXCEPTION 'Unauthorized: User does not belong to this business';
    END IF;

    SELECT name, current_due INTO v_cust_name, v_prev_due 
    FROM customers WHERE id = p_customer_id AND business_id = p_business_id 
    FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Customer not found in this business';
    END IF;

    v_new_due := GREATEST(0, v_prev_due - p_amount);
    v_ref := 'DUE-' || to_char(CURRENT_TIMESTAMP, 'YYYYMMDD-HH24MISS');

    -- Update Customer ledger
    UPDATE customers 
    SET current_due = v_new_due, 
        total_paid = total_paid + p_amount, 
        updated_at = CURRENT_TIMESTAMP 
    WHERE id = p_customer_id;

    -- Record customer transaction
    INSERT INTO customer_transactions (
        business_id, customer_id, customer_name, transaction_type,
        amount, balance_after, payment_method, reference_id, note
    ) VALUES (
        p_business_id, p_customer_id, v_cust_name, 'due_payment',
        p_amount, v_new_due, p_payment_method, v_ref, COALESCE(p_note, 'Due payment collection')
    );

    -- Credit Account
    IF p_account_id IS NOT NULL THEN
        UPDATE accounts 
        SET balance = balance + p_amount, updated_at = CURRENT_TIMESTAMP 
        WHERE id = p_account_id AND business_id = p_business_id;

        INSERT INTO account_transactions (
            business_id, account_id, transaction_type, amount, balance_after, reference_id, note
        )
        SELECT p_business_id, id, 'customer_due_collection', p_amount, balance, v_ref, 'Due collected from ' || v_cust_name
        FROM accounts WHERE id = p_account_id;
    END IF;

    -- Audit log
    INSERT INTO audit_logs (
        business_id, action, entity_type, entity_id, details
    ) VALUES (
        p_business_id, 'CUSTOMER_DUE_COLLECTED', 'customer', p_customer_id::TEXT,
        'Collected ' || p_amount || ' due from ' || v_cust_name || ', Remaining: ' || v_new_due
    );

    RETURN jsonb_build_object(
        'success', true,
        'customer_id', p_customer_id,
        'amount', p_amount,
        'previous_due', v_prev_due,
        'new_due', v_new_due,
        'reference', v_ref
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;


-- 6. Atomic Supplier Due Payment RPC
CREATE OR REPLACE FUNCTION pay_supplier_due_balance(
    p_business_id UUID,
    p_supplier_id UUID,
    p_amount NUMERIC,
    p_payment_method VARCHAR(50),
    p_account_id UUID,
    p_note TEXT DEFAULT NULL
)
RETURNS JSONB AS $$
DECLARE
    v_supp_name VARCHAR(150);
    v_prev_due NUMERIC;
    v_new_due NUMERIC;
    v_acc_bal NUMERIC;
    v_ref VARCHAR(100);
BEGIN
    IF p_amount <= 0 THEN
        RAISE EXCEPTION 'Payment amount must be greater than zero';
    END IF;

    IF auth.uid() IS NOT NULL AND NOT user_belongs_to_business(p_business_id) THEN
        RAISE EXCEPTION 'Unauthorized: User does not belong to this business';
    END IF;

    SELECT name, current_due INTO v_supp_name, v_prev_due 
    FROM suppliers WHERE id = p_supplier_id AND business_id = p_business_id 
    FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Supplier not found in this business';
    END IF;

    -- Check account balance
    IF p_account_id IS NOT NULL THEN
        SELECT balance INTO v_acc_bal FROM accounts 
        WHERE id = p_account_id AND business_id = p_business_id FOR UPDATE;

        IF v_acc_bal IS NOT NULL AND v_acc_bal < p_amount THEN
            RAISE EXCEPTION 'Insufficient balance in payment account (Balance: %, Payment: %)', v_acc_bal, p_amount;
        END IF;

        UPDATE accounts 
        SET balance = balance - p_amount, updated_at = CURRENT_TIMESTAMP 
        WHERE id = p_account_id;
    END IF;

    v_new_due := GREATEST(0, v_prev_due - p_amount);
    v_ref := 'SPAY-' || to_char(CURRENT_TIMESTAMP, 'YYYYMMDD-HH24MISS');

    -- Update supplier ledger
    UPDATE suppliers 
    SET current_due = v_new_due, 
        total_paid = total_paid + p_amount, 
        updated_at = CURRENT_TIMESTAMP 
    WHERE id = p_supplier_id;

    -- Record supplier transaction
    INSERT INTO supplier_transactions (
        business_id, supplier_id, supplier_name, transaction_type,
        amount, balance_after, payment_method, reference_id, note
    ) VALUES (
        p_business_id, p_supplier_id, v_supp_name, 'due_payment',
        p_amount, v_new_due, p_payment_method, v_ref, COALESCE(p_note, 'Supplier due payment')
    );

    -- Record account transaction
    IF p_account_id IS NOT NULL THEN
        INSERT INTO account_transactions (
            business_id, account_id, transaction_type, amount, balance_after, reference_id, note
        )
        SELECT p_business_id, id, 'supplier_due_payment', -p_amount, balance, v_ref, 'Supplier payment to ' || v_supp_name
        FROM accounts WHERE id = p_account_id;
    END IF;

    -- Audit log
    INSERT INTO audit_logs (
        business_id, action, entity_type, entity_id, details
    ) VALUES (
        p_business_id, 'SUPPLIER_DUE_PAID', 'supplier', p_supplier_id::TEXT,
        'Paid ' || p_amount || ' due to ' || v_supp_name || ', Remaining: ' || v_new_due
    );

    RETURN jsonb_build_object(
        'success', true,
        'supplier_id', p_supplier_id,
        'amount', p_amount,
        'previous_due', v_prev_due,
        'new_due', v_new_due,
        'reference', v_ref
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
