-- ============================================================================
-- AMAR DOKAN PRO - SELLER MANAGEMENT & MULTI-USER UPGRADE
-- Migration 20261104000000: Seller Role, Schema Updates, RLS, & Atomic RPC
-- ============================================================================

-- 1. Schema Enhancements on Sales Table
ALTER TABLE sales 
ADD COLUMN IF NOT EXISTS seller_id UUID REFERENCES user_profiles(id) ON DELETE SET NULL;

ALTER TABLE sales 
ADD COLUMN IF NOT EXISTS seller_name VARCHAR(150);

CREATE INDEX IF NOT EXISTS idx_sales_seller_id ON sales(seller_id);
CREATE INDEX IF NOT EXISTS idx_sales_branch_id ON sales(branch_id);

-- 2. Schema Enhancements on User Profiles
ALTER TABLE user_profiles 
ADD COLUMN IF NOT EXISTS username VARCHAR(100);

CREATE INDEX IF NOT EXISTS idx_user_profiles_username ON user_profiles(username);

-- 3. Update business_users role constraint to include 'seller'
DO $$ 
BEGIN
    ALTER TABLE business_users DROP CONSTRAINT IF EXISTS business_users_role_check;
    ALTER TABLE business_users ADD CONSTRAINT business_users_role_check 
    CHECK (role IN ('owner', 'admin', 'manager', 'salesman', 'seller', 'storekeeper', 'accountant', 'hr'));
EXCEPTION
    WHEN OTHERS THEN
        NULL;
END $$;

-- 4. Update complete_sale_transaction RPC to persist seller_id and seller_name
CREATE OR REPLACE FUNCTION complete_sale_transaction(
    p_sale JSONB,
    p_items JSONB,
    p_payments JSONB
)
RETURNS JSONB AS $$
DECLARE
    v_sale_id UUID;
    v_business_id UUID;
    v_branch_id UUID;
    v_invoice_num VARCHAR(100);
    v_seller_id UUID;
    v_seller_name VARCHAR(150);
    v_item RECORD;
    v_payment RECORD;
    v_prev_stock NUMERIC;
    v_new_stock NUMERIC;
    v_prod_name VARCHAR(255);
BEGIN
    v_business_id := (p_sale->>'business_id')::UUID;
    v_branch_id := (p_sale->>'branch_id')::UUID;
    v_invoice_num := p_sale->>'invoice_number';
    v_seller_id := NULLIF(p_sale->>'seller_id', '')::UUID;
    v_seller_name := COALESCE(p_sale->>'seller_name', p_sale->>'served_by', 'Seller');

    -- 1. Insert Master Sale Record
    INSERT INTO sales (
        business_id, branch_id, invoice_number, customer_id, customer_name,
        customer_mobile, subtotal, discount, vat_tax_rate, vat_tax_amount,
        total, paid, due, payment_method, status, served_by, seller_id, seller_name, notes
    ) VALUES (
        v_business_id,
        v_branch_id,
        v_invoice_num,
        NULLIF(p_sale->>'customer_id', '')::UUID,
        p_sale->>'customer_name',
        p_sale->>'customer_mobile',
        (p_sale->>'subtotal')::NUMERIC,
        COALESCE((p_sale->>'discount')::NUMERIC, 0),
        COALESCE((p_sale->>'vat_tax_rate')::NUMERIC, 0),
        COALESCE((p_sale->>'vat_tax_amount')::NUMERIC, 0),
        (p_sale->>'total')::NUMERIC,
        (p_sale->>'paid')::NUMERIC,
        (p_sale->>'due')::NUMERIC,
        p_sale->>'payment_method',
        p_sale->>'status',
        COALESCE(p_sale->>'served_by', v_seller_name),
        v_seller_id,
        v_seller_name,
        p_sale->>'notes'
    ) RETURNING id INTO v_sale_id;

    -- 2. Insert Sale Items & Deduct Stock
    FOR v_item IN SELECT * FROM jsonb_to_recordset(p_items) AS x(
        product_id UUID, variant_id UUID, product_name VARCHAR, sku VARCHAR,
        variant_details VARCHAR, quantity NUMERIC, unit_price NUMERIC,
        purchase_price NUMERIC, discount NUMERIC, total NUMERIC
    )
    LOOP
        INSERT INTO sale_items (
            sale_id, product_id, variant_id, product_name, sku,
            variant_details, quantity, unit_price, purchase_price, discount, total
        ) VALUES (
            v_sale_id, v_item.product_id, v_item.variant_id, v_item.product_name,
            v_item.sku, v_item.variant_details, v_item.quantity, v_item.unit_price,
            v_item.purchase_price, v_item.discount, v_item.total
        );

        -- Get current stock
        SELECT current_stock, name INTO v_prev_stock, v_prod_name FROM products WHERE id = v_item.product_id FOR UPDATE;
        v_new_stock := GREATEST(0, v_prev_stock - v_item.quantity);

        -- Update Product stock
        UPDATE products SET current_stock = v_new_stock, updated_at = CURRENT_TIMESTAMP WHERE id = v_item.product_id;

        -- Record Stock Movement
        INSERT INTO stock_movements (
            business_id, branch_id, product_id, variant_id, product_name,
            movement_type, quantity, previous_stock, new_stock, reference, note
        ) VALUES (
            v_business_id, v_branch_id, v_item.product_id, v_item.variant_id, v_prod_name,
            'sale_out', -v_item.quantity, v_prev_stock, v_new_stock, v_invoice_num, 'বিক্রি ইনভয়েস: ' || v_invoice_num
        );
    END LOOP;

    -- 3. Insert Payments & Credit Accounts
    FOR v_payment IN SELECT * FROM jsonb_to_recordset(p_payments) AS p(
        account_id UUID, payment_method VARCHAR, amount NUMERIC, trx_id VARCHAR
    )
    LOOP
        IF v_payment.amount > 0 THEN
            INSERT INTO sale_payments (
                sale_id, account_id, payment_method, amount, trx_id
            ) VALUES (
                v_sale_id, v_payment.account_id, v_payment.payment_method, v_payment.amount, v_payment.trx_id
            );

            -- Update account balance
            IF v_payment.account_id IS NOT NULL THEN
                UPDATE accounts
                SET balance = balance + v_payment.amount, updated_at = CURRENT_TIMESTAMP
                WHERE id = v_payment.account_id;

                INSERT INTO account_transactions (
                    business_id, account_id, transaction_type, amount, balance_after, reference_id, note
                )
                SELECT v_business_id, v_payment.account_id, 'sale_payment', v_payment.amount, balance, v_invoice_num, 'বিক্রি আদায়: ' || v_invoice_num
                FROM accounts WHERE id = v_payment.account_id;
            END IF;
        END IF;
    END LOOP;

    -- 4. Customer Due Ledger Update
    IF (p_sale->>'customer_id') IS NOT NULL AND (p_sale->>'due')::NUMERIC > 0 THEN
        UPDATE customers
        SET current_due = current_due + (p_sale->>'due')::NUMERIC,
            total_purchase = total_purchase + (p_sale->>'total')::NUMERIC,
            total_paid = total_paid + (p_sale->>'paid')::NUMERIC,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = (p_sale->>'customer_id')::UUID;

        INSERT INTO customer_transactions (
            business_id, customer_id, customer_name, transaction_type,
            amount, balance_after, payment_method, reference_id, note
        )
        SELECT v_business_id, id, name, 'sale_due', (p_sale->>'due')::NUMERIC, current_due, p_sale->>'payment_method', v_invoice_num, 'বিক্রি বাকি: ' || v_invoice_num
        FROM customers WHERE id = (p_sale->>'customer_id')::UUID;
    ELSIF (p_sale->>'customer_id') IS NOT NULL THEN
        UPDATE customers
        SET total_purchase = total_purchase + (p_sale->>'total')::NUMERIC,
            total_paid = total_paid + (p_sale->>'paid')::NUMERIC,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = (p_sale->>'customer_id')::UUID;
    END IF;

    -- Return sale result
    RETURN jsonb_build_object(
        'success', true,
        'sale_id', v_sale_id,
        'invoice_number', v_invoice_num
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 5. Row Level Security Policies on Sales
ALTER TABLE sales ENABLE ROW LEVEL SECURITY;

-- Helper function to check if authenticated user is admin or owner
CREATE OR REPLACE FUNCTION is_business_admin(p_business_id UUID)
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM business_users
        WHERE business_id = p_business_id
          AND user_id = auth.uid()
          AND role IN ('owner', 'admin')
          AND status = 'active'
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Drop existing RLS policies on sales if any
DROP POLICY IF EXISTS "Sales select policy" ON sales;
DROP POLICY IF EXISTS "Sales delete policy" ON sales;
DROP POLICY IF EXISTS "Sales insert policy" ON sales;
DROP POLICY IF EXISTS "Sales update policy" ON sales;

-- Select Policy: Admins see all business sales; Sellers see only their own sales
CREATE POLICY "Sales select policy" ON sales
FOR SELECT TO authenticated
USING (
    is_business_admin(business_id)
    OR seller_id = auth.uid()
    OR served_by = (SELECT email FROM user_profiles WHERE id = auth.uid())
);

-- Delete Policy: Strictly restricted to Admin / Owner. Sellers can NEVER delete sales!
CREATE POLICY "Sales delete policy" ON sales
FOR DELETE TO authenticated
USING (
    is_business_admin(business_id)
);

-- Update Policy: Admins can update sales; Sellers cannot alter past completed invoices
CREATE POLICY "Sales update policy" ON sales
FOR UPDATE TO authenticated
USING (
    is_business_admin(business_id)
);

-- Insert Policy: Authenticated users can insert sales for their business
CREATE POLICY "Sales insert policy" ON sales
FOR INSERT TO authenticated
WITH CHECK (
    user_belongs_to_business(business_id)
);

-- 6. RPC for Admin to create or link seller profile safely
CREATE OR REPLACE FUNCTION register_seller_profile(
    p_business_id UUID,
    p_seller_id UUID,
    p_email VARCHAR,
    p_full_name VARCHAR,
    p_username VARCHAR,
    p_mobile VARCHAR,
    p_branch_id UUID,
    p_status VARCHAR DEFAULT 'active'
)
RETURNS JSONB AS $$
BEGIN
    -- Verify caller is Admin or Owner
    IF auth.uid() IS NOT NULL AND NOT is_business_admin(p_business_id) THEN
        RAISE EXCEPTION 'Only an Admin or Owner can create or register sellers.';
    END IF;

    -- Upsert user profile
    INSERT INTO user_profiles (id, email, full_name, username, mobile)
    VALUES (p_seller_id, p_email, p_full_name, p_username, p_mobile)
    ON CONFLICT (id) DO UPDATE SET
        full_name = EXCLUDED.full_name,
        username = COALESCE(EXCLUDED.username, user_profiles.username),
        mobile = COALESCE(EXCLUDED.mobile, user_profiles.mobile),
        updated_at = CURRENT_TIMESTAMP;

    -- Upsert business_users membership
    INSERT INTO business_users (business_id, user_id, branch_id, role, status)
    VALUES (p_business_id, p_seller_id, p_branch_id, 'seller', COALESCE(p_status, 'active'))
    ON CONFLICT (business_id, user_id) DO UPDATE SET
        branch_id = EXCLUDED.branch_id,
        role = 'seller',
        status = EXCLUDED.status,
        updated_at = CURRENT_TIMESTAMP;

    RETURN jsonb_build_object(
        'success', true,
        'user_id', p_seller_id,
        'message', 'Seller registered successfully'
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
