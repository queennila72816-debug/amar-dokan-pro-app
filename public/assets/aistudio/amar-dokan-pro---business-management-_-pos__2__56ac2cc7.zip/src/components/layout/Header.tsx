import React from 'react';
import { useApp } from '../../context/AppContext';
import { UserRole } from '../../types';
import { Store, ShoppingCart, Globe, Shield, Sparkles, Building2, LogOut } from 'lucide-react';

interface HeaderProps {
  onOpenPOS: () => void;
  activeTab: string;
}

export const Header: React.FC<HeaderProps> = ({ onOpenPOS, activeTab }) => {
  const { settings, updateSettings, currentUserRole, setCurrentUserRole, branches, activeBranchId, setActiveBranchId, user, signOut } = useApp();
  const isBn = settings.language === 'bn';

  const roleLabels: Record<UserRole, string> = {
    owner: 'Admin (Owner)',
    admin: 'Admin',
    seller: 'Seller',
    salesman: 'Seller',
    manager: 'Manager',
    storekeeper: 'Storekeeper',
    accountant: 'Accountant',
  };

  const currentBranch = branches.find(b => b.id === activeBranchId) || branches[0];

  return (
    <header className="h-14 sm:h-16 bg-white border-b border-slate-200 px-3 sm:px-4 md:px-6 flex items-center justify-between sticky top-0 z-30 select-none">
      {/* Zone 1: Brand Wordmark */}
      <div className="flex items-center gap-2 sm:gap-3 min-w-0">
        <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-lg bg-emerald-600 flex items-center justify-center text-white shadow-sm shadow-emerald-700/20 shrink-0">
          <Store className="w-4 h-4 sm:w-5 sm:h-5" />
        </div>
        <div className="flex flex-col min-w-0">
          <span className="text-xs sm:text-base md:text-lg font-bold tracking-tight text-slate-900 leading-tight truncate">
            {settings.shopName || 'Amar Dokan Pro'}
          </span>
          <span className="text-[11px] text-slate-500 hidden sm:inline truncate">
            Smart Business &amp; POS Engine
          </span>
        </div>
      </div>

      {/* Zone 2: Navigation & Contextual Info */}
      <div className="hidden lg:flex items-center gap-4">
        {/* Branch Selector */}
        <div className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 rounded-lg border border-slate-200 text-xs text-slate-700">
          <Building2 className="w-3.5 h-3.5 text-slate-500" />
          <span className="text-slate-600">Branch:</span>
          <select
            aria-label="Select Branch"
            value={activeBranchId}
            onChange={(e) => setActiveBranchId(e.target.value)}
            className="bg-transparent font-medium text-slate-900 focus:outline-none cursor-pointer"
          >
            {branches.map(b => (
              <option key={b.id} value={b.id}>
                {b.name}
              </option>
            ))}
          </select>
        </div>

        {/* Easy vs Advanced Mode */}
        <button
          onClick={() => updateSettings({ uiMode: settings.uiMode === 'easy' ? 'advanced' : 'easy' })}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-medium transition-colors ${
            settings.uiMode === 'easy'
              ? 'bg-amber-50 text-amber-800 border-amber-200 hover:bg-amber-100'
              : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
          }`}
          title="Toggle Easy / Advanced mode"
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-600" />
          <span>{settings.uiMode === 'easy' ? 'Easy Mode' : 'Advanced'}</span>
        </button>

        {/* Role Switcher for Fast Demonstration of Access Rules */}
        <div className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 rounded-lg border border-slate-200 text-xs">
          <Shield className="w-3.5 h-3.5 text-emerald-600" />
          <span className="text-slate-600">Role:</span>
          <select
            aria-label="Select User Role"
            value={currentUserRole}
            onChange={(e) => setCurrentUserRole(e.target.value as UserRole)}
            className="bg-transparent font-semibold text-slate-900 focus:outline-none cursor-pointer"
          >
            {(Object.keys(roleLabels) as UserRole[]).map(role => (
              <option key={role} value={role}>
                {roleLabels[role]}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Zone 3: Primary Action & Controls */}
      <div className="flex items-center gap-1.5 sm:gap-2 md:gap-3 shrink-0">
        {/* Language Badge */}
        <div className="hidden sm:flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium rounded-lg text-slate-700 bg-slate-50 border border-slate-200">
          <Globe className="w-3.5 h-3.5 text-emerald-600" />
          <span>English</span>
        </div>

        {/* Primary POS Button - hidden on small mobile when already on POS tab */}
        {activeTab !== 'pos' ? (
          <button
            onClick={onOpenPOS}
            className="flex items-center gap-1.5 sm:gap-2 px-2.5 sm:px-3.5 py-1.5 sm:py-2 text-xs md:text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 active:scale-[0.98] transition-all rounded-lg shadow-sm shadow-emerald-700/20 whitespace-nowrap"
          >
            <ShoppingCart className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            <span className="hidden sm:inline">New Sale (POS)</span>
            <span className="sm:hidden">POS</span>
          </button>
        ) : (
          <div className="sm:hidden flex items-center gap-1 px-2 py-1 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-lg text-[11px] font-semibold">
            <ShoppingCart className="w-3.5 h-3.5" />
            <span>POS</span>
          </div>
        )}

        {/* User Profile & Role Badge */}
        <div className="flex items-center gap-1.5 sm:gap-2 px-1.5 sm:px-2 py-1 rounded-lg bg-slate-50 border border-slate-200">
          <div className="w-7 h-7 rounded-full bg-emerald-100 text-emerald-800 font-bold text-xs flex items-center justify-center shrink-0">
            {(user?.user_metadata?.full_name || user?.email || (currentUserRole === 'seller' || currentUserRole === 'salesman' ? 'S' : 'A')).slice(0, 1).toUpperCase()}
          </div>
          <div className="hidden md:flex flex-col min-w-0 text-left">
            <span className="text-xs font-bold text-slate-800 truncate max-w-[110px]">
              {user?.user_metadata?.full_name || user?.email?.split('@')[0] || (currentUserRole === 'seller' || currentUserRole === 'salesman' ? 'Seller Terminal' : 'Store Admin')}
            </span>
          </div>
          <span
            className={`px-2 py-0.5 rounded-full text-[10px] font-bold tracking-wide uppercase ${
              currentUserRole === 'seller' || currentUserRole === 'salesman'
                ? 'bg-blue-100 text-blue-800 border border-blue-300'
                : 'bg-emerald-100 text-emerald-800 border border-emerald-300'
            }`}
          >
            {currentUserRole === 'seller' || currentUserRole === 'salesman' ? 'Seller' : 'Admin'}
          </span>
        </div>

        {/* User Sign Out */}
        <button
          onClick={() => signOut()}
          title={user ? `Signed in as ${user.email}. Click to Sign Out` : 'Sign Out'}
          className="flex items-center gap-1.5 p-1.5 sm:p-2 text-xs font-semibold text-slate-600 hover:text-rose-600 hover:bg-rose-50 rounded-lg border border-slate-200 transition-colors cursor-pointer"
        >
          <LogOut className="w-4 h-4" />
          <span className="hidden xl:inline">Logout</span>
        </button>
      </div>
    </header>
  );
};
