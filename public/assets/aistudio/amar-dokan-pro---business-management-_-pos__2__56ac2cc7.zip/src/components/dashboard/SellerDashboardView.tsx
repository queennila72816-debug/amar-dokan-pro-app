import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { Sale } from '../../types';
import { formatCurrency, formatDate } from '../../utils/formatters';
import { InvoiceModal } from '../pos/InvoiceModal';
import { supabase, isSupabaseConfigured } from '../../lib/supabase';
import {
  ShoppingCart,
  Receipt,
  TrendingUp,
  Banknote,
  Smartphone,
  Building2,
  AlertCircle,
  Eye,
  Lock,
  CheckCircle2,
  Clock,
  Sparkles,
  Loader2,
  X,
  CreditCard,
} from 'lucide-react';

interface SellerDashboardViewProps {
  onOpenPOS: () => void;
}

export const SellerDashboardView: React.FC<SellerDashboardViewProps> = ({ onOpenPOS }) => {
  const { sales, user, currentUserRole, settings, branches, activeBranchId } = useApp();
  const lang = settings.language;

  // Selected invoice for viewing
  const [selectedInvoice, setSelectedInvoice] = useState<Sale | null>(null);

  // Change Password Modal
  const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isUpdatingPassword, setIsUpdatingPassword] = useState(false);
  const [passwordFeedback, setPasswordFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const sellerDisplayName =
    user?.user_metadata?.full_name || user?.email?.split('@')[0] || (currentUserRole === 'seller' ? 'Seller' : 'Staff');

  const currentBranch = branches.find(b => b.id === activeBranchId) || branches[0];

  // Filter sales made by this seller only
  const sellerSales = useMemo(() => {
    return sales.filter(s => {
      if (user?.id && s.sellerId === user.id) return true;
      if (s.servedBy === sellerDisplayName || s.sellerName === sellerDisplayName) return true;
      if (user?.email && s.servedBy === user.email) return true;
      // In local mode if only one seller or testing
      if (currentUserRole === 'seller' || currentUserRole === 'salesman') {
        return true;
      }
      return false;
    });
  }, [sales, user, sellerDisplayName, currentUserRole]);

  // Today's Date range
  const todayStart = useMemo(() => {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    return d.getTime();
  }, []);

  const todaySales = useMemo(() => {
    return sellerSales.filter(s => {
      const saleTime = new Date(s.date).getTime();
      return saleTime >= todayStart && s.status !== 'voided' && s.status !== 'returned';
    });
  }, [sellerSales, todayStart]);

  // Today's Metrics
  const todayTotalAmount = useMemo(() => {
    return todaySales.reduce((acc, curr) => acc + curr.total, 0);
  }, [todaySales]);

  const todayTransactionCount = todaySales.length;

  const todayAvgTicket = todayTransactionCount > 0 ? Math.round(todayTotalAmount / todayTransactionCount) : 0;

  // Breakdown by payment method today
  const methodBreakdown = useMemo(() => {
    const breakdown = {
      cash: 0,
      bkash: 0,
      nagad: 0,
      bank: 0,
      due: 0,
    };

    todaySales.forEach(s => {
      // Due portion
      if (s.due > 0) {
        breakdown.due += s.due;
      }

      // Paid portions
      if (s.payments && s.payments.length > 0) {
        s.payments.forEach(p => {
          if (p.method === 'cash') breakdown.cash += p.amount;
          else if (p.method === 'bkash') breakdown.bkash += p.amount;
          else if (p.method === 'nagad') breakdown.nagad += p.amount;
          else if (p.method === 'bank' || p.method === 'card') breakdown.bank += p.amount;
          else breakdown.cash += p.amount;
        });
      } else {
        if (s.paymentMethod === 'cash') breakdown.cash += s.paid;
        else if (s.paymentMethod === 'bkash') breakdown.bkash += s.paid;
        else if (s.paymentMethod === 'nagad') breakdown.nagad += s.paid;
        else if (s.paymentMethod === 'bank' || s.paymentMethod === 'card') breakdown.bank += s.paid;
        else breakdown.cash += s.paid;
      }
    });

    return breakdown;
  }, [todaySales]);

  // Recent transactions (last 15)
  const recentTransactions = useMemo(() => {
    return [...sellerSales]
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      .slice(0, 15);
  }, [sellerSales]);

  // Handle password update
  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordFeedback(null);

    if (newPassword.length < 6) {
      setPasswordFeedback({ type: 'error', text: 'Password must be at least 6 characters long.' });
      return;
    }
    if (newPassword !== confirmPassword) {
      setPasswordFeedback({ type: 'error', text: 'Passwords do not match.' });
      return;
    }

    setIsUpdatingPassword(true);
    try {
      if (isSupabaseConfigured) {
        const { error } = await supabase.auth.updateUser({ password: newPassword });
        if (error) throw error;
      }
      setPasswordFeedback({ type: 'success', text: 'Password changed successfully!' });
      setTimeout(() => {
        setIsPasswordModalOpen(false);
        setNewPassword('');
        setConfirmPassword('');
        setPasswordFeedback(null);
      }, 1200);
    } catch (err: any) {
      setPasswordFeedback({ type: 'error', text: err.message || 'Failed to update password.' });
    } finally {
      setIsUpdatingPassword(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-emerald-700 via-teal-700 to-emerald-800 rounded-2xl p-5 sm:p-6 text-white shadow-md flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white/15 text-[11px] font-semibold text-emerald-100 mb-2 backdrop-blur-xs">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>Seller Terminal &bull; {currentBranch?.name || 'Main Branch'}</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight">
            Welcome back, {sellerDisplayName}!
          </h1>
          <p className="text-xs text-emerald-100 mt-1">
            Here is your daily sales summary and transaction history for today.
          </p>
        </div>

        <div className="flex items-center gap-2.5 w-full sm:w-auto">
          <button
            onClick={() => {
              setIsPasswordModalOpen(true);
              setPasswordFeedback(null);
            }}
            className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3 py-2 bg-white/10 hover:bg-white/20 active:scale-95 border border-white/20 rounded-xl text-xs font-semibold text-white transition-all cursor-pointer"
          >
            <Lock className="w-3.5 h-3.5" />
            <span>Change Password</span>
          </button>

          <button
            onClick={onOpenPOS}
            className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-900 rounded-xl text-xs sm:text-sm font-bold shadow-md active:scale-95 transition-all cursor-pointer"
          >
            <ShoppingCart className="w-4 h-4 text-slate-900" />
            <span>Open POS / New Sale</span>
          </button>
        </div>
      </div>

      {/* Today's High-Level KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-medium">Today's Sales</span>
            <TrendingUp className="w-4 h-4 text-emerald-600" />
          </div>
          <p className="text-xl sm:text-2xl font-bold text-slate-900 font-mono-num">
            {formatCurrency(todayTotalAmount, lang)}
          </p>
          <span className="text-[11px] text-emerald-700 font-semibold">Your sales today</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-medium">Transactions Today</span>
            <Receipt className="w-4 h-4 text-blue-600" />
          </div>
          <p className="text-xl sm:text-2xl font-bold text-slate-900 font-mono-num">
            {todayTransactionCount}
          </p>
          <span className="text-[11px] text-slate-500">Invoices completed</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-medium">Cash Collected</span>
            <Banknote className="w-4 h-4 text-emerald-600" />
          </div>
          <p className="text-xl sm:text-2xl font-bold text-slate-900 font-mono-num">
            {formatCurrency(methodBreakdown.cash, lang)}
          </p>
          <span className="text-[11px] text-slate-500">In cash drawer</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-medium">Average Sale</span>
            <Receipt className="w-4 h-4 text-purple-600" />
          </div>
          <p className="text-xl sm:text-2xl font-bold text-slate-900 font-mono-num">
            {formatCurrency(todayAvgTicket, lang)}
          </p>
          <span className="text-[11px] text-slate-500">Per transaction</span>
        </div>
      </div>

      {/* Payment Method Breakdown */}
      <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs">
        <h3 className="text-xs sm:text-sm font-bold text-slate-900 uppercase tracking-wider mb-3">
          Today's Sales Breakdown by Payment Method
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          {/* Cash */}
          <div className="p-3 rounded-xl bg-emerald-50/70 border border-emerald-200/80">
            <div className="flex items-center gap-1.5 text-emerald-800 text-xs font-semibold mb-1">
              <Banknote className="w-4 h-4 text-emerald-600" />
              <span>Cash</span>
            </div>
            <p className="text-base sm:text-lg font-bold text-slate-900 font-mono-num">
              {formatCurrency(methodBreakdown.cash, lang)}
            </p>
          </div>

          {/* bKash */}
          <div className="p-3 rounded-xl bg-pink-50/70 border border-pink-200/80">
            <div className="flex items-center gap-1.5 text-pink-800 text-xs font-semibold mb-1">
              <Smartphone className="w-4 h-4 text-pink-600" />
              <span>bKash</span>
            </div>
            <p className="text-base sm:text-lg font-bold text-slate-900 font-mono-num">
              {formatCurrency(methodBreakdown.bkash, lang)}
            </p>
          </div>

          {/* Nagad */}
          <div className="p-3 rounded-xl bg-orange-50/70 border border-orange-200/80">
            <div className="flex items-center gap-1.5 text-orange-800 text-xs font-semibold mb-1">
              <Smartphone className="w-4 h-4 text-orange-600" />
              <span>Nagad</span>
            </div>
            <p className="text-base sm:text-lg font-bold text-slate-900 font-mono-num">
              {formatCurrency(methodBreakdown.nagad, lang)}
            </p>
          </div>

          {/* Bank / Card */}
          <div className="p-3 rounded-xl bg-blue-50/70 border border-blue-200/80">
            <div className="flex items-center gap-1.5 text-blue-800 text-xs font-semibold mb-1">
              <Building2 className="w-4 h-4 text-blue-600" />
              <span>Bank / Card</span>
            </div>
            <p className="text-base sm:text-lg font-bold text-slate-900 font-mono-num">
              {formatCurrency(methodBreakdown.bank, lang)}
            </p>
          </div>

          {/* Due */}
          <div className="p-3 rounded-xl bg-amber-50/70 border border-amber-200/80">
            <div className="flex items-center gap-1.5 text-amber-800 text-xs font-semibold mb-1">
              <CreditCard className="w-4 h-4 text-amber-600" />
              <span>Customer Due</span>
            </div>
            <p className="text-base sm:text-lg font-bold text-slate-900 font-mono-num">
              {formatCurrency(methodBreakdown.due, lang)}
            </p>
          </div>
        </div>
      </div>

      {/* Recent Transactions Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h3 className="font-bold text-slate-900 text-sm sm:text-base">Your Recent Transactions</h3>
            <p className="text-xs text-slate-500">Invoices completed under your seller account</p>
          </div>
          <button
            onClick={onOpenPOS}
            className="flex items-center gap-1.5 text-xs font-semibold text-emerald-700 hover:text-emerald-800 bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-200 transition-colors"
          >
            <ShoppingCart className="w-3.5 h-3.5" />
            <span>New Sale</span>
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600">
              <tr>
                <th className="px-4 py-3 font-semibold">Invoice #</th>
                <th className="px-4 py-3 font-semibold">Date &amp; Time</th>
                <th className="px-4 py-3 font-semibold">Customer</th>
                <th className="px-4 py-3 font-semibold text-right">Total</th>
                <th className="px-4 py-3 font-semibold text-right">Paid</th>
                <th className="px-4 py-3 font-semibold text-right">Due</th>
                <th className="px-4 py-3 font-semibold">Method</th>
                <th className="px-4 py-3 font-semibold">Status</th>
                <th className="px-4 py-3 font-semibold text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {recentTransactions.map(sale => (
                <tr key={sale.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="px-4 py-3 font-mono font-bold text-slate-900">
                    {sale.invoiceNumber}
                  </td>
                  <td className="px-4 py-3 text-slate-600 whitespace-nowrap">
                    {formatDate(sale.date, lang)}
                  </td>
                  <td className="px-4 py-3 font-medium text-slate-800">
                    {sale.customerName}
                  </td>
                  <td className="px-4 py-3 text-right font-mono-num font-bold text-slate-900">
                    {formatCurrency(sale.total, lang)}
                  </td>
                  <td className="px-4 py-3 text-right font-mono-num text-emerald-700 font-semibold">
                    {formatCurrency(sale.paid, lang)}
                  </td>
                  <td className="px-4 py-3 text-right font-mono-num font-bold">
                    <span className={sale.due > 0 ? 'text-rose-700' : 'text-slate-400'}>
                      {sale.due > 0 ? formatCurrency(sale.due, lang) : '—'}
                    </span>
                  </td>
                  <td className="px-4 py-3 capitalize text-slate-700 font-medium">
                    {sale.paymentMethod}
                  </td>
                  <td className="px-4 py-3">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        sale.status === 'paid'
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : sale.status === 'due'
                          ? 'bg-rose-50 text-rose-700 border border-rose-200'
                          : sale.status === 'partial'
                          ? 'bg-amber-50 text-amber-700 border border-amber-200'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {sale.status.toUpperCase()}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <button
                      onClick={() => setSelectedInvoice(sale)}
                      className="inline-flex items-center gap-1 px-2.5 py-1 text-slate-700 bg-slate-100 hover:bg-slate-200 rounded font-semibold transition-colors cursor-pointer"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>View</span>
                    </button>
                  </td>
                </tr>
              ))}

              {recentTransactions.length === 0 && (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-400">
                    <Receipt className="w-8 h-8 mx-auto mb-2 opacity-40" />
                    <p className="font-medium">No sales recorded yet under your account.</p>
                    <button
                      onClick={onOpenPOS}
                      className="mt-2 text-emerald-700 font-semibold hover:underline"
                    >
                      Click here to start a sale at POS
                    </button>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Invoice Modal */}
      {selectedInvoice && (
        <InvoiceModal
          sale={selectedInvoice}
          onClose={() => setSelectedInvoice(null)}
          settings={settings}
        />
      )}

      {/* Change Password Modal */}
      {isPasswordModalOpen && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 w-full max-w-md overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between p-4 border-b border-slate-200 bg-slate-50">
              <div className="flex items-center gap-2">
                <Lock className="w-4 h-4 text-emerald-600" />
                <h3 className="font-bold text-slate-900 text-sm sm:text-base">Change My Password</h3>
              </div>
              <button
                onClick={() => setIsPasswordModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleChangePassword} className="p-4 sm:p-6 space-y-4">
              {passwordFeedback && (
                <div
                  className={`p-3 text-xs rounded-lg flex items-center gap-2 ${
                    passwordFeedback.type === 'success'
                      ? 'bg-emerald-50 border border-emerald-200 text-emerald-800'
                      : 'bg-rose-50 border border-rose-200 text-rose-800'
                  }`}
                >
                  {passwordFeedback.type === 'success' ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  )}
                  <span>{passwordFeedback.text}</span>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">New Password</label>
                <input
                  type="password"
                  required
                  value={newPassword}
                  onChange={e => setNewPassword(e.target.value)}
                  placeholder="At least 6 characters"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Confirm New Password</label>
                <input
                  type="password"
                  required
                  value={confirmPassword}
                  onChange={e => setConfirmPassword(e.target.value)}
                  placeholder="Re-type new password"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsPasswordModalOpen(false)}
                  className="px-4 py-2 border border-slate-200 text-slate-700 rounded-lg text-xs font-medium hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isUpdatingPassword}
                  className="flex items-center gap-2 px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold"
                >
                  {isUpdatingPassword ? <Loader2 className="w-4 h-4 animate-spin" /> : <span>Update Password</span>}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
