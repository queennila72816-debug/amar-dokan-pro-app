import { supabase } from '../lib/supabase';
import { Customer, CustomerTransaction, Supplier, SupplierTransaction, Account, AccountTransaction, Expense, Employee, Purchase } from '../types';

export const customerService = {
  async fetchCustomers(businessId?: string): Promise<Customer[]> {
    let query = supabase.from('customers').select('*').order('created_at', { ascending: false });
    if (businessId) query = query.eq('business_id', businessId);
    const { data, error } = await query;
    if (error) throw error;
    return (data || []).map((c: any) => ({
      id: c.id,
      name: c.name,
      mobile: c.mobile,
      address: c.address || undefined,
      email: c.email || undefined,
      customerType: c.customer_type || 'retail',
      openingDue: Number(c.opening_due || 0),
      currentDue: Number(c.current_due || 0),
      creditLimit: Number(c.credit_limit || 0),
      totalPurchase: Number(c.total_purchase || 0),
      totalPaid: Number(c.total_paid || 0),
      createdAt: c.created_at,
      notes: c.notes || undefined,
    }));
  },

  async insertCustomer(data: Omit<Customer, 'id' | 'createdAt' | 'currentDue' | 'totalPurchase' | 'totalPaid' | 'openingDue'> & { openingDue?: number }, businessId: string): Promise<Customer> {
    const opDue = data.openingDue || 0;
    const payload = {
      business_id: businessId,
      name: data.name,
      mobile: data.mobile,
      address: data.address || null,
      email: data.email || null,
      customer_type: data.customerType || 'retail',
      opening_due: opDue,
      current_due: opDue,
      credit_limit: data.creditLimit || 0,
      total_purchase: opDue,
      total_paid: 0,
      notes: data.notes || null,
    };
    const { data: res, error } = await supabase.from('customers').insert(payload).select().single();
    if (error) throw error;
    return {
      id: res.id,
      name: res.name,
      mobile: res.mobile,
      address: res.address || undefined,
      email: res.email || undefined,
      customerType: res.customer_type || 'retail',
      openingDue: Number(res.opening_due || 0),
      currentDue: Number(res.current_due || 0),
      creditLimit: Number(res.credit_limit || 0),
      totalPurchase: Number(res.total_purchase || 0),
      totalPaid: Number(res.total_paid || 0),
      createdAt: res.created_at,
      notes: res.notes || undefined,
    };
  },

  async updateCustomer(id: string, data: Partial<Customer>, businessId?: string): Promise<void> {
    const payload: any = { updated_at: new Date().toISOString() };
    if (data.name !== undefined) payload.name = data.name;
    if (data.mobile !== undefined) payload.mobile = data.mobile;
    if (data.address !== undefined) payload.address = data.address;
    if (data.email !== undefined) payload.email = data.email;
    if (data.customerType !== undefined) payload.customer_type = data.customerType;
    if (data.currentDue !== undefined) payload.current_due = data.currentDue;
    if (data.creditLimit !== undefined) payload.credit_limit = data.creditLimit;
    if (data.totalPurchase !== undefined) payload.total_purchase = data.totalPurchase;
    if (data.totalPaid !== undefined) payload.total_paid = data.totalPaid;
    if (data.notes !== undefined) payload.notes = data.notes;

    let query = supabase.from('customers').update(payload).eq('id', id);
    if (businessId) query = query.eq('business_id', businessId);
    const { error } = await query;
    if (error) throw error;
  },

  async deleteCustomer(id: string, businessId?: string): Promise<void> {
    let query = supabase.from('customers').delete().eq('id', id);
    if (businessId) query = query.eq('business_id', businessId);
    const { error } = await query;
    if (error) throw error;
  },

  async collectDue(
    customerId: string,
    amount: number,
    paymentMethod: string,
    accountId: string,
    businessId: string,
    note?: string
  ): Promise<{ previousDue: number; newDue: number }> {
    const { data, error } = await supabase.rpc('collect_customer_due_payment', {
      p_business_id: businessId,
      p_customer_id: customerId,
      p_amount: amount,
      p_payment_method: paymentMethod,
      p_account_id: accountId,
      p_note: note || null,
    });

    if (error) {
      // Direct verification fallback
      const { data: cust, error: cErr } = await supabase.from('customers').select('current_due, total_paid, name').eq('id', customerId).single();
      if (cErr) throw cErr;

      const prevDue = Number(cust.current_due || 0);
      const newDue = Math.max(0, prevDue - amount);
      const totalPaid = Number(cust.total_paid || 0) + amount;

      const { error: updErr } = await supabase.from('customers').update({
        current_due: newDue,
        total_paid: totalPaid,
        updated_at: new Date().toISOString(),
      }).eq('id', customerId);
      if (updErr) throw updErr;

      // Credit account
      if (accountId) {
        const { data: acc } = await supabase.from('accounts').select('balance').eq('id', accountId).single();
        if (acc) {
          const newBal = Number(acc.balance || 0) + amount;
          await supabase.from('accounts').update({ balance: newBal, updated_at: new Date().toISOString() }).eq('id', accountId);
          await supabase.from('account_transactions').insert({
            business_id: businessId,
            account_id: accountId,
            transaction_type: 'customer_due_collection',
            amount,
            balance_after: newBal,
            reference_id: `DUE-${Date.now()}`,
            note: `Due payment collection from ${cust.name}`,
          });
        }
      }

      await supabase.from('customer_transactions').insert({
        business_id: businessId,
        customer_id: customerId,
        customer_name: cust.name,
        transaction_type: 'due_payment',
        amount,
        balance_after: newDue,
        payment_method: paymentMethod,
        reference_id: `DUE-${Date.now()}`,
        note: note || 'Due payment collection',
      });

      return { previousDue: prevDue, newDue };
    }

    return {
      previousDue: Number(data.previous_due),
      newDue: Number(data.new_due),
    };
  },
};

export const supplierService = {
  async fetchSuppliers(businessId?: string): Promise<Supplier[]> {
    let query = supabase.from('suppliers').select('*').order('created_at', { ascending: false });
    if (businessId) query = query.eq('business_id', businessId);
    const { data, error } = await query;
    if (error) throw error;
    return (data || []).map((s: any) => ({
      id: s.id,
      name: s.name,
      company: s.company,
      mobile: s.mobile,
      address: s.address || undefined,
      email: s.email || undefined,
      openingDue: Number(s.opening_due || 0),
      currentDue: Number(s.current_due || 0),
      totalPurchase: Number(s.total_purchase || 0),
      totalPaid: Number(s.total_paid || 0),
      createdAt: s.created_at,
    }));
  },

  async insertSupplier(data: Omit<Supplier, 'id' | 'createdAt' | 'currentDue' | 'totalPurchase' | 'totalPaid' | 'openingDue'> & { openingDue?: number }, businessId: string): Promise<Supplier> {
    const opDue = data.openingDue || 0;
    const payload = {
      business_id: businessId,
      name: data.name,
      company: data.company,
      mobile: data.mobile,
      address: data.address || null,
      email: data.email || null,
      opening_due: opDue,
      current_due: opDue,
      total_purchase: opDue,
      total_paid: 0,
    };
    const { data: res, error } = await supabase.from('suppliers').insert(payload).select().single();
    if (error) throw error;
    return {
      id: res.id,
      name: res.name,
      company: res.company,
      mobile: res.mobile,
      address: res.address || undefined,
      email: res.email || undefined,
      openingDue: Number(res.opening_due || 0),
      currentDue: Number(res.current_due || 0),
      totalPurchase: Number(res.total_purchase || 0),
      totalPaid: Number(res.total_paid || 0),
      createdAt: res.created_at,
    };
  },

  async updateSupplier(id: string, data: Partial<Supplier>, businessId?: string): Promise<void> {
    const payload: any = { updated_at: new Date().toISOString() };
    if (data.name !== undefined) payload.name = data.name;
    if (data.company !== undefined) payload.company = data.company;
    if (data.mobile !== undefined) payload.mobile = data.mobile;
    if (data.address !== undefined) payload.address = data.address;
    if (data.email !== undefined) payload.email = data.email;
    if (data.currentDue !== undefined) payload.current_due = data.currentDue;
    if (data.totalPurchase !== undefined) payload.total_purchase = data.totalPurchase;
    if (data.totalPaid !== undefined) payload.total_paid = data.totalPaid;

    let query = supabase.from('suppliers').update(payload).eq('id', id);
    if (businessId) query = query.eq('business_id', businessId);
    const { error } = await query;
    if (error) throw error;
  },

  async deleteSupplier(id: string, businessId?: string): Promise<void> {
    let query = supabase.from('suppliers').delete().eq('id', id);
    if (businessId) query = query.eq('business_id', businessId);
    const { error } = await query;
    if (error) throw error;
  },

  async payDue(
    supplierId: string,
    amount: number,
    paymentMethod: string,
    accountId: string,
    businessId: string,
    note?: string
  ): Promise<{ previousDue: number; newDue: number }> {
    const { data, error } = await supabase.rpc('pay_supplier_due_balance', {
      p_business_id: businessId,
      p_supplier_id: supplierId,
      p_amount: amount,
      p_payment_method: paymentMethod,
      p_account_id: accountId,
      p_note: note || null,
    });

    if (error) {
      // Direct verification fallback
      const { data: supp, error: sErr } = await supabase.from('suppliers').select('current_due, total_paid, name').eq('id', supplierId).single();
      if (sErr) throw sErr;

      const prevDue = Number(supp.current_due || 0);
      const newDue = Math.max(0, prevDue - amount);
      const totalPaid = Number(supp.total_paid || 0) + amount;

      // Check and deduct account balance
      if (accountId) {
        const { data: acc, error: aErr } = await supabase.from('accounts').select('balance').eq('id', accountId).single();
        if (aErr) throw aErr;
        if (Number(acc.balance || 0) < amount) {
          throw new Error('Insufficient balance in payment account');
        }
        const newBal = Number(acc.balance || 0) - amount;
        await supabase.from('accounts').update({ balance: newBal, updated_at: new Date().toISOString() }).eq('id', accountId);
        await supabase.from('account_transactions').insert({
          business_id: businessId,
          account_id: accountId,
          transaction_type: 'supplier_due_payment',
          amount: -amount,
          balance_after: newBal,
          reference_id: `SPAY-${Date.now()}`,
          note: `Due payment to ${supp.name}`,
        });
      }

      const { error: updErr } = await supabase.from('suppliers').update({
        current_due: newDue,
        total_paid: totalPaid,
        updated_at: new Date().toISOString(),
      }).eq('id', supplierId);
      if (updErr) throw updErr;

      await supabase.from('supplier_transactions').insert({
        business_id: businessId,
        supplier_id: supplierId,
        supplier_name: supp.name,
        transaction_type: 'due_payment',
        amount,
        balance_after: newDue,
        payment_method: paymentMethod,
        reference_id: `SPAY-${Date.now()}`,
        note: note || 'Supplier due payment',
      });

      return { previousDue: prevDue, newDue };
    }

    return {
      previousDue: Number(data.previous_due),
      newDue: Number(data.new_due),
    };
  },
};

export const financeService = {
  async fetchAccounts(businessId?: string): Promise<Account[]> {
    let query = supabase.from('accounts').select('*').order('created_at', { ascending: true });
    if (businessId) query = query.eq('business_id', businessId);
    const { data, error } = await query;
    if (error) throw error;
    return (data || []).map((a: any) => ({
      id: a.id,
      name: a.name,
      accountType: a.account_type,
      accountNumber: a.account_number || undefined,
      balance: Number(a.balance || 0),
    }));
  },

  async fetchExpenses(businessId?: string): Promise<Expense[]> {
    let query = supabase.from('expenses').select('*').order('created_at', { ascending: false });
    if (businessId) query = query.eq('business_id', businessId);
    const { data, error } = await query;
    if (error) throw error;
    return (data || []).map((e: any) => ({
      id: e.id,
      date: e.date || e.created_at,
      category: e.category,
      amount: Number(e.amount || 0),
      paymentMethod: e.payment_method,
      accountId: e.account_id,
      paidTo: e.paid_to || undefined,
      note: e.note || undefined,
    }));
  },

  async insertExpense(expense: Omit<Expense, 'id' | 'date'>, businessId: string, branchId?: string): Promise<Expense> {
    const payload = {
      business_id: businessId,
      branch_id: branchId || null,
      account_id: expense.accountId,
      category: expense.category,
      amount: expense.amount,
      payment_method: expense.paymentMethod,
      paid_to: expense.paidTo || null,
      note: expense.note || null,
      date: new Date().toISOString(),
    };
    const { data, error } = await supabase.from('expenses').insert(payload).select().single();
    if (error) throw error;

    // Deduct from account in Supabase
    const { data: acc } = await supabase.from('accounts').select('balance').eq('id', expense.accountId).single();
    if (acc) {
      const newBal = Number(acc.balance || 0) - expense.amount;
      await supabase.from('accounts').update({ balance: newBal, updated_at: new Date().toISOString() }).eq('id', expense.accountId);
      await supabase.from('account_transactions').insert({
        business_id: businessId,
        account_id: expense.accountId,
        transaction_type: 'expense',
        amount: -expense.amount,
        balance_after: newBal,
        reference_id: data.id,
        note: `Expense: ${expense.category}`,
      });
    }

    return {
      id: data.id,
      date: data.date,
      category: data.category,
      amount: Number(data.amount),
      paymentMethod: data.payment_method,
      accountId: data.account_id,
      paidTo: data.paid_to || undefined,
      note: data.note || undefined,
    };
  },

  async transferFunds(
    fromAccountId: string,
    toAccountId: string,
    amount: number,
    businessId: string,
    note?: string
  ): Promise<{ success: boolean; referenceId?: string }> {
    // Call atomic transfer_account_funds RPC
    const { data, error } = await supabase.rpc('transfer_account_funds', {
      p_business_id: businessId,
      p_from_account_id: fromAccountId,
      p_to_account_id: toAccountId,
      p_amount: amount,
      p_note: note || null,
    });

    if (error) {
      // Fallback: If RPC is pending in migration, execute sequential updates with error rollback
      const { data: fromAcc, error: fErr } = await supabase.from('accounts').select('balance, name').eq('id', fromAccountId).single();
      if (fErr) throw fErr;
      if (Number(fromAcc.balance || 0) < amount) {
        throw new Error(`Insufficient balance in ${fromAcc.name}`);
      }

      const { data: toAcc, error: tErr } = await supabase.from('accounts').select('balance, name').eq('id', toAccountId).single();
      if (tErr) throw tErr;

      const newFromBal = Number(fromAcc.balance || 0) - amount;
      const newToBal = Number(toAcc.balance || 0) + amount;

      const { error: updFErr } = await supabase.from('accounts').update({ balance: newFromBal, updated_at: new Date().toISOString() }).eq('id', fromAccountId);
      if (updFErr) throw updFErr;

      const { error: updTErr } = await supabase.from('accounts').update({ balance: newToBal, updated_at: new Date().toISOString() }).eq('id', toAccountId);
      if (updTErr) {
        // Rollback source
        await supabase.from('accounts').update({ balance: fromAcc.balance }).eq('id', fromAccountId);
        throw updTErr;
      }

      const refId = `TRF-${Date.now()}`;
      await supabase.from('account_transactions').insert([
        { business_id: businessId, account_id: fromAccountId, transaction_type: 'transfer_out', amount: -amount, balance_after: newFromBal, reference_id: refId, note: note || `Transfer to ${toAcc.name}` },
        { business_id: businessId, account_id: toAccountId, transaction_type: 'transfer_in', amount: amount, balance_after: newToBal, reference_id: refId, note: note || `Transfer from ${fromAcc.name}` }
      ]);

      return { success: true, referenceId: refId };
    }

    return { success: true, referenceId: data?.reference_id };
  },
};

export const inventoryService = {
  async adjustStock(
    productId: string,
    adjustedQty: number,
    reason: string,
    businessId: string,
    branchId: string,
    note?: string
  ): Promise<{ previousStock: number; newStock: number }> {
    const { data, error } = await supabase.rpc('adjust_product_stock', {
      p_business_id: businessId,
      p_branch_id: branchId,
      p_product_id: productId,
      p_adjusted_qty: adjustedQty,
      p_reason: reason,
      p_note: note || null,
    });

    if (error) {
      // Fallback: update product and record movement with strict verification
      const { data: prod, error: pErr } = await supabase.from('products').select('current_stock, name').eq('id', productId).single();
      if (pErr) throw pErr;

      const prevStock = Number(prod.current_stock || 0);
      const newStock = Math.max(0, prevStock + adjustedQty);

      const { error: uErr } = await supabase.from('products').update({ current_stock: newStock, updated_at: new Date().toISOString() }).eq('id', productId);
      if (uErr) throw uErr;

      await supabase.from('stock_movements').insert({
        business_id: businessId,
        branch_id: branchId,
        product_id: productId,
        product_name: prod.name,
        movement_type: 'adjustment',
        quantity: adjustedQty,
        previous_stock: prevStock,
        new_stock: newStock,
        note: `Adjustment: ${reason} (${note || ''})`,
      });

      return { previousStock: prevStock, newStock };
    }

    return {
      previousStock: Number(data.previous_stock),
      newStock: Number(data.new_stock),
    };
  },

  async transferBranchStock(
    productId: string,
    quantity: number,
    fromBranchId: string,
    toBranchId: string,
    businessId: string,
    note?: string
  ): Promise<{ success: boolean; reference?: string }> {
    const { data, error } = await supabase.rpc('transfer_branch_stock', {
      p_business_id: businessId,
      p_product_id: productId,
      p_quantity: quantity,
      p_from_branch_id: fromBranchId,
      p_to_branch_id: toBranchId,
      p_note: note || null,
    });

    if (error) {
      // Direct verification fallback
      const { data: prod, error: pErr } = await supabase.from('products').select('name, current_stock').eq('id', productId).single();
      if (pErr) throw pErr;

      const ref = `TF-${Date.now()}`;
      await supabase.from('stock_movements').insert([
        {
          business_id: businessId,
          branch_id: fromBranchId,
          product_id: productId,
          product_name: prod.name,
          movement_type: 'transfer_out',
          quantity: -quantity,
          previous_stock: prod.current_stock,
          new_stock: prod.current_stock,
          reference: ref,
          note: `Transfer to destination branch ${note ? `(${note})` : ''}`,
        },
        {
          business_id: businessId,
          branch_id: toBranchId,
          product_id: productId,
          product_name: prod.name,
          movement_type: 'transfer_in',
          quantity: quantity,
          previous_stock: 0,
          new_stock: quantity,
          reference: ref,
          note: `Transfer from source branch ${note ? `(${note})` : ''}`,
        }
      ]);

      return { success: true, reference: ref };
    }

    return { success: true, reference: data?.reference };
  },
};

export const purchaseService = {
  async fetchPurchases(businessId?: string): Promise<Purchase[]> {
    let query = supabase.from('purchases').select('*, purchase_items(*)').order('created_at', { ascending: false });
    if (businessId) query = query.eq('business_id', businessId);
    const { data, error } = await query;
    if (error) throw error;
    return (data || []).map((p: any) => ({
      id: p.id,
      invoiceNumber: p.invoice_number,
      supplierId: p.supplier_id,
      supplierName: p.supplier_name,
      date: p.created_at,
      items: (p.purchase_items || []).map((i: any) => ({
        productId: i.product_id,
        productName: i.product_name,
        quantity: Number(i.quantity),
        purchasePrice: Number(i.purchase_price),
        total: Number(i.total),
      })),
      subtotal: Number(p.subtotal),
      discount: Number(p.discount || 0),
      transportCost: Number(p.transport_cost || 0),
      otherCost: Number(p.other_cost || 0),
      total: Number(p.total),
      paid: Number(p.paid),
      due: Number(p.due),
      paymentMethod: p.payment_method,
      status: p.status,
      branchId: p.branch_id,
      notes: p.notes || undefined,
    }));
  },

  async completePurchase(purchase: Purchase, businessId: string): Promise<{ success: boolean; purchaseId?: string }> {
    // Call atomic complete_purchase_transaction RPC
    const p_purchase = {
      business_id: businessId,
      branch_id: purchase.branchId,
      supplier_id: purchase.supplierId || null,
      supplier_name: purchase.supplierName,
      invoice_number: purchase.invoiceNumber,
      subtotal: purchase.subtotal,
      transport_cost: purchase.transportCost || 0,
      other_cost: purchase.otherCost || 0,
      total: purchase.total,
      paid: purchase.paid,
      due: purchase.due,
      payment_method: purchase.paymentMethod,
      notes: purchase.notes || null,
    };

    const p_items = purchase.items.map(i => ({
      product_id: i.productId,
      product_name: i.productName,
      quantity: i.quantity,
      purchase_price: i.purchasePrice,
      sale_price: (i as any).salePrice || 0,
      total: i.total,
    }));

    const { data, error } = await supabase.rpc('complete_purchase_transaction', {
      p_purchase,
      p_items,
    });

    if (error) {
      // Fallback if RPC is pending in postgres: perform verified step-by-step insert
      const { data: purRes, error: purErr } = await supabase
        .from('purchases')
        .insert(p_purchase)
        .select()
        .single();
      if (purErr) throw purErr;

      const itemsPayload = purchase.items.map(i => ({
        purchase_id: purRes.id,
        product_id: i.productId,
        product_name: i.productName,
        quantity: i.quantity,
        purchase_price: i.purchasePrice,
        sale_price: (i as any).salePrice || 0,
        total: i.total,
      }));

      const { error: itemErr } = await supabase.from('purchase_items').insert(itemsPayload);
      if (itemErr) throw itemErr;

      // Update product stocks
      for (const item of purchase.items) {
        const { data: curProd } = await supabase.from('products').select('current_stock').eq('id', item.productId).single();
        const prevStock = Number(curProd?.current_stock || 0);
        const newStock = prevStock + item.quantity;
        await supabase.from('products').update({ current_stock: newStock, purchase_price: item.purchasePrice, updated_at: new Date().toISOString() }).eq('id', item.productId);
        await supabase.from('stock_movements').insert({
          business_id: businessId,
          branch_id: purchase.branchId,
          product_id: item.productId,
          product_name: item.productName,
          movement_type: 'purchase_in',
          quantity: item.quantity,
          previous_stock: prevStock,
          new_stock: newStock,
          reference: purchase.invoiceNumber,
          note: `Purchase: ${purchase.invoiceNumber}`,
        });
      }

      // Update supplier if due
      if (purchase.supplierId) {
        const { data: curSupp } = await supabase.from('suppliers').select('current_due, total_purchase, total_paid').eq('id', purchase.supplierId).single();
        if (curSupp) {
          await supabase.from('suppliers').update({
            current_due: Number(curSupp.current_due || 0) + purchase.due,
            total_purchase: Number(curSupp.total_purchase || 0) + purchase.total,
            total_paid: Number(curSupp.total_paid || 0) + purchase.paid,
            updated_at: new Date().toISOString(),
          }).eq('id', purchase.supplierId);
        }
      }

      return { success: true, purchaseId: purRes.id };
    }

    return { success: true, purchaseId: data?.purchase_id };
  },
};
